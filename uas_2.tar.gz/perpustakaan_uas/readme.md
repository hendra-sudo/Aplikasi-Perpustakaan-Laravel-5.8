email : admin@gmail.com
pass : 12345678

email : hendra@gmail.com
pass : 12345678

Akun Aplikasi Perpustakaan Versi 1.1 
email : adminperpus@info.com
pass : admin123
