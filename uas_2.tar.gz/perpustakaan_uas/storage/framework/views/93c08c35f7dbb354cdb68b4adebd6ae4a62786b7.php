<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <br>
            <?php if(session('sukses')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(session('sukses')); ?>

            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-5">
                    <h1>Daftar Pengembalian</h1>
                </div>
                <div class="col-7">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                        Tambah Data Pengembalian
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Masukan data pengembalian buku</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="/pengembalian/create" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Kode Kembali</label>
                                            <input type="name" name="kode_kembali" class="form-control" id="kode_kembali" placeholder="Kode Kembali">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Tanggal Kembali</label>
                                            <input type="name" name="tgl_kembali" class="form-control" id="tgl_kembali" placeholder="Tanggal Kembali">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Jatuh Tempo</label>
                                            <input type="name" name="jatuh_tempo" class="form-control" id="jatuh_tempo" placeholder="Jatuh Tempo">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Denda Per Hari</label>
                                            <input type="text" name="denda_per_hari" class="form-control" id="denda_per_hari" placeholder="Denda Per Hari">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Jumlah Hari</label>
                                            <input type="name" name="jumlah_hari" class="form-control" id="jumlah_hari" placeholder="Jumlah Hari">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Total Denda</label>
                                            <input type="name" name="total" class="form-control" id="total" placeholder="Total Denda">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Kode Petugas</label>
                                            <input type="name" name="kode_petugas" class="form-control" id="kode_petugas" placeholder="Kode Petugas">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Kode Anggota</label>
                                            <input type="name" name="kode_anggota" class="form-control" id="kode_anggota" placeholder="Kode Anggota">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Kode Buku</label>
                                            <input type="name" name="kode_buku" class="form-control" id="kode_buku" placeholder="Kode Buku">
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <table class="table table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Kode Kembali</th>
                            <th>Tanggal Kembali</th>
                            <th>Jatuh Tempo</th>
                            <th>Denda Per Hari</th>
                            <th>Jumlah Hari</th>
                            <th>Total Denda</th>
                            <th>Kode Petugas</th>
                            <th>Kode Anggota</th>
                            <th>Kode Buku</th>
                            <th>AKSI</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_pengembalian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengembalian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($pengembalian->kode_kembali); ?></td>
                            <td><?php echo e($pengembalian->tgl_kembali); ?></td>
                            <td><?php echo e($pengembalian->jatuh_tempo); ?></td>
                            <td><?php echo e($pengembalian->denda_per_hari); ?></td>
                            <td><?php echo e($pengembalian->jumlah_hari); ?></td>
                            <td><?php echo e($pengembalian->total); ?></td>
                            <td><?php echo e($pengembalian->kode_petugas); ?></td>
                            <td><?php echo e($pengembalian->kode_anggota); ?></td>
                            <td><?php echo e($pengembalian->kode_buku); ?></td>
                            <td>
                                <a href="/pengembalian/<?php echo e($pengembalian->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                                <a href="/pengembalian/<?php echo e($pengembalian->id); ?>/delete" class="btn btn-danger btn-sm">Delete</a>

                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\... SEMESTER 5\A_Pemrograman Berbasis Framework\UAS\New folder\aplikasiperpustakaanlaravel-main\aplikasi_perpustakaan_naufal_28_xiirpl3\resources\views/pengembalian/index.blade.php ENDPATH**/ ?>