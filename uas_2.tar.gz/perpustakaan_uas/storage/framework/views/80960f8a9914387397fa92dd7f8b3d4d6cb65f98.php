<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <br>
            <h1>Edit data petugas</h1>
            <?php if(session('sukses')): ?>
            <div class="alert alert-primary" role="alert">
                Data pustakawan berhasil di update!
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                    <form action="/pustakawan/<?php echo e($petugas->id); ?>/update" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Kode Petugas</label>
                            <input type="name" name="kode_petugas" class="form-control" id="kode_petugas" value="<?php echo e($petugas->kode_petugas); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Petugas</label>
                            <input type="name" name="nama" class="form-control" id="nama" value="<?php echo e($petugas->nama); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Jabatan</label>
                            <input type="name" name="jabatan" class="form-control" id="jabatan" value="<?php echo e($petugas->jabatan); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Jam Tugas</label>
                            <input type="name" name="jam_tugas" class="form-control" id="jam_tugas" value="<?php echo e($petugas->jam_tugas); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">No Telp</label>
                            <input type="name" name="no_telp" class="form-control" id="no_telp" value="<?php echo e($petugas->no_telp); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Alamat</label>
                            <textarea class="form-control" name="alamat" id="alamat" rows="3"><?php echo e($petugas->alamat); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-warning">Update</button>

                    </form>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\... SEMESTER 5\A_Pemrograman Berbasis Framework\UAS\New folder\perpustakaanlaravel- uas -R\aplikasi_perpustakaan_uas -R\resources\views/pustakawan/edit.blade.php ENDPATH**/ ?>