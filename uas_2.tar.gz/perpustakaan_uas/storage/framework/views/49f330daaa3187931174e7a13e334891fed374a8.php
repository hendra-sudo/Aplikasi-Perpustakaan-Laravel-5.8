<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <br>
            <h1>Edit data anggota</h1>
            <?php if(session('sukses')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(session('sukses')); ?>

            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                    <form action="/siswa/<?php echo e($anggota->id); ?>/update" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Kode Anggota</label>
                            <input type="name" name="kode_anggota" class="form-control" id="kode_anggota" value="<?php echo e($anggota->kode_anggota); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Siswa</label>
                            <input type="name" name="nama" class="form-control" id="nama" value="<?php echo e($anggota->nama); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Jurusan</label>
                            <input type="name" name="jurusan" class="form-control" id="jurusan" value="<?php echo e($anggota->jurusan); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Angkatan</label>
                            <input type="name" name="angkatan" class="form-control" id="angkatan" value="<?php echo e($anggota->angkatan); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Alamat</label>
                            <textarea class="form-control" name="alamat" id="exampleFormControlTextarea1" rows="3"><?php echo e($anggota->alamat); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-warning">Update</button>

                    </form>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\... SEMESTER 5\A_Pemrograman Berbasis Framework\UAS\New folder\perpustakaanlaravel- uas -R\aplikasi_perpustakaan_uas -R\resources\views/siswa/edit.blade.php ENDPATH**/ ?>