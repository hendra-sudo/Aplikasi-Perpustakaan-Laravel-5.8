<!DOCTYPE html>
<html>

<head>
    <title>
        Aplikasi Perpustakaan
    </title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/css/bootstrap.min.css" integrity="sha384-VCmXjywReHh4PwowAiWNagnWcLhlEJLA5buUprzK8rxFgeH0kww/aWY76TfkUoSX" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1>Edit data siswa</h1>
        <?php if(session('sukses')): ?>
        <div class="alert alert-primary" role="alert">
            Data siswa berhasil di update!
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <form action="/peminjaman/<?php echo e($peminjaman->id); ?>/update" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Kode Pinjam</label>
                        <input type="name" name="kode_pinjam" class="form-control" id="kode_pinjam" value="<?php echo e($peminjaman->kode_pinjam); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Tanggal Pinjam</label>
                        <input type="name" name="tgl_pinjam" class="form-control" id="tgl_pinjam" value="<?php echo e($peminjaman->tgl_pinjam); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Tanggal Kembali</label>
                        <input type="name" name="tgl_kembali" class="form-control" id="tgl_kembali" value="<?php echo e($peminjaman->tgl_kembali); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Kode Petugas</label>
                        <input type="text" name="kode_petugas" class="form-control" id="kode_petugas" value="<?php echo e($peminjaman->kode_petugas); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Kode Anggota</label>
                        <input type="text" name="kode_anggota" class="form-control" id="kode_anggota" value="<?php echo e($peminjaman->kode_anggota); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Kode Buku</label>
                        <input type="text" name="kode_buku" class="form-control" id="kode_buku" value="<?php echo e($peminjaman->kode_buku); ?>">
                    </div>
                    <button type="submit" class="btn btn-warning">Update</button>

                </form>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/js/bootstrap.min.js" integrity="sha384-XEerZL0cuoUbHE4nZReLT7nx9gQrQreJekYhJD9WNWhH8nEW+0c5qq7aIo2Wl30J" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\aplikasi_perpustakaan_naufal_28_xiirpl3\resources\views/peminjaman/edit.blade.php ENDPATH**/ ?>