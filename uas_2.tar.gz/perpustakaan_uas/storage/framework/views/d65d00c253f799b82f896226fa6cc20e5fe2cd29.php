<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <br>
            <h1>Edit data rak</h1>
            <?php if(session('sukses')): ?>
            <div class="alert alert-primary" role="alert">
                Data rak berhasil di update!
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                    <form action="/rak/<?php echo e($rak->id); ?>/update" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Kode Rak</label>
                            <input type="name" name="kode_rak" class="form-control" id="kode_rak" value="<?php echo e($rak->kode_rak); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama Rak</label>
                            <input type="name" name="nama_rak" class="form-control" id="nama_rak" value="<?php echo e($rak->nama_rak); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Kode Buku</label>
                            <input type="name" name="kode_buku" class="form-control" id="kode_buku" value="<?php echo e($rak->kode_buku); ?>">
                        </div>
                        <button type="submit" class="btn btn-warning">Update</button>

                    </form>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aplikasi_perpustakaan_naufal_28_xiirpl3\resources\views/rak/edit.blade.php ENDPATH**/ ?>