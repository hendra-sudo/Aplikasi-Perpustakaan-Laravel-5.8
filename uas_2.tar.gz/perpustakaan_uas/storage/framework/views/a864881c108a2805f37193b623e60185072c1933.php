<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="text-center">
                <h1 class="h3 mb-4 text-gray-800">Support</h1>
                <div class="row">
                    <div class="col-lg">
                        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
                            <div class="card-body p-0">
                                <div class="row">
                                    <div class="col-lg">
                                        <div class="p-5">
                                            <form>
                                                <a href="https://www.instagram.com/naufalfaridd/">
                                                    <img src="<?php echo e(asset('instagram.png')); ?>" alt weidht="50" height="50" class="img-responsive"></img>
                                                </a>
                                                <a href="https://wa.me/089632994007/">
                                                    <img src="<?php echo e(asset('whatsapp.png')); ?>" alt weidht="50" height="50" class="img-responsive"></img>
                                                </a>
                                                <a href="https://web.facebook.com/pak.mul.3154/">
                                                    <img src="<?php echo e(asset('facebook.png')); ?>" alt weidht="50" height="50" class="img-responsive"></img>
                                                </a>
                                                <a href="https://twitter.com/naufalfard/">
                                                    <img src="<?php echo e(asset('twitter.png')); ?>" alt weidht="48" height="48" class="img-responsive"></img>
                                                </a>
                                                <br>
                                                Developed By <a href=""><b>naufalfarid</b>
                                            </form>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </main>
    <?php $__env->stopSection(); ?>`
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\... SEMESTER 5\A_Pemrograman Berbasis Framework\UAS\New folder\aplikasiperpustakaanlaravel-main\aplikasi_perpustakaan_naufal_28_xiirpl3\resources\views/about/index.blade.php ENDPATH**/ ?>