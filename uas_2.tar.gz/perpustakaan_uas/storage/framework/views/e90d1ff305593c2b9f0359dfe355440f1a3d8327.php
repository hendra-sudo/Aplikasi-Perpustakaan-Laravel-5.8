<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <br>
            <h1>Edit data buku</h1>
            <?php if(session('sukses')): ?>
            <div class="alert alert-primary" role="alert">
                Data pustakawan berhasil di update!
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                    <form action="/buku/<?php echo e($buku->id); ?>/update" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Kode Buku</label>
                            <input type="name" name="kode_buku" class="form-control" id="kode_buku" value="<?php echo e($buku->kode_buku); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Judul Buku</label>
                            <input type="name" name="judul" class="form-control" id="judul" value="<?php echo e($buku->judul); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Penulis</label>
                            <input type="name" name="penulis" class="form-control" id="penulis" value="<?php echo e($buku->penulis); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Penerbit</label>
                            <input type="name" name="penerbit" class="form-control" id="penerbit" value="<?php echo e($buku->penerbit); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tahun Terbit</label>
                            <input type="name" name="tahun_terbit" class="form-control" id="tahun_terbit" value="<?php echo e($buku->tahun_terbit); ?>">
                        </div>
                        <button type="submit" class="btn btn-warning">Update</button>

                    </form>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aplikasi_perpustakaan_naufal_28_xiirpl3\resources\views/buku/edit.blade.php ENDPATH**/ ?>