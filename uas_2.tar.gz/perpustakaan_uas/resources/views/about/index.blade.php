@extends('layouts.master')

@section('content')
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="text-center">
                <h1 class="h3 mb-4 text-gray-800">Support</h1>
                <div class="row">
                    <div class="col-lg">
                        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
                            <div class="card-body p-0">
                                <div class="row">
                                    <div class="col-lg">
                                        <div class="p-5">
                                            <form>
                                                
                                                <br>
                                                Developed By <a href=""><b>Framework_A || Kelompok_3 </b>
                                            </form>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </main>
    @endsection`
